<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {

	public function index()
	{
		$data['title'] = array('hindi'=>'My Profile','english'=>'My Profile');
		$this->load->view('user/index',$data);
	}


	public function view($id="")
	{
		$data['fullname'] = "Pawan Dubey";
		$data['id'] = $id;

		print_r($data);

		// $this->load->view('user/index',$data);
	}
}
