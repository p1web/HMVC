<?php 
// parent controller for out modular based controller


class MY_Controller extends MX_Controller
{
	
	function __construct()
	{
		parent::__construct();

		
	}
}

 ?>